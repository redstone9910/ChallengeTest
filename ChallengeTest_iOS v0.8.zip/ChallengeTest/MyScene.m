//
//  MyScene.m
//  ChallengeTest
//
//  Created by YinYanhui on 14-11-13.
//  Copyright (c) 2014年 YinYanhui. All rights reserved.
//

#import "MyScene.h"

@implementation MyScene

ChickenBoard *mBoard;
NSMutableArray *mBoardList;
NSMutableArray *mChickenList;

-(id)initWithSize:(CGSize)size
{
    if (self = [super initWithSize:size])
    {
        /* Setup your scene here */
        
        self.backgroundColor = [SKColor colorWithRed:0.15 green:0.15 blue:0.3 alpha:1.0];
        
        _sChicken = nil;
        
        mBoardList = [NSMutableArray array];
        float chickenWidth;
        float x0, y0;
        if (CGRectGetWidth(self.frame) > CGRectGetHeight(self.frame))
        {
            x0 = CGRectGetWidth(self.frame) - CGRectGetHeight(self.frame);
            y0 = 0;
            chickenWidth = CGRectGetHeight(self.frame);
        }
        else
        {
            y0 = CGRectGetHeight(self.frame) - CGRectGetWidth(self.frame);
            x0 = 0;
            chickenWidth = CGRectGetWidth(self.frame);
        }
        //chickenWidth *= 0.5;
		[mBoardList addObject: [ChickenBoard newWithValue : nil : x0 : y0 : chickenWidth]];
        
        mChickenList = [NSMutableArray array];
		
		for(int i = 0; i < ROWNUM * ROWNUM; i ++)
		{
            ChickenBoard *tBoard = mBoardList[0];
            ChickenNode *tNode = [[tBoard.mNode objectAtIndex:i / ROWNUM] objectAtIndex: i % ROWNUM];
            
            [mChickenList addObject:[ChickenSprite newWithAlloc : tNode->w]];
            [mChickenList[i] setPosition:CGPointMake(tNode->x, tNode->y)];
            [mChickenList[i] updateNodePos: tNode->x: tNode->y];
            [mChickenList[i] setStatus: tNode->v];
            
            [self addChild:mChickenList[i]];
        }
        
			/*mChickenList.add(new ChickenSprite( 0, 0, mBallRegion.getWidth(),
                                         mBallRegion.getHeight(), mBallRegion,getVertexBufferObjectManager() )
                          {
                              bBoard mBoard;
                              @Override
                              public boolean onAreaTouched(TouchEvent pSceneTouchEvent,
                                                           float pTouchAreaLocalX, float pTouchAreaLocalY)
                              {
                                  // TODO Auto-generated method stub
                                  
                                  //mBoard = mBoardList.get(mBoardList.size() - 1);
                                  
                                  float tx = pSceneTouchEvent.getX() - this.getWidth() / 2;
                                  float ty = pSceneTouchEvent.getY() - this.getHeight() / 2;
                                  switch(pSceneTouchEvent.getAction())
                                  {
                                      case TouchEvent.ACTION_DOWN:
                                      {
                                      }
                                      case TouchEvent.ACTION_MOVE:
                                      {
                                          return true;
                                      }
                                      case TouchEvent.ACTION_UP:
                                      {                                          return true;
                                      }
                                      default:
                                      {
                                          break;
                                      }
                                  }
                                  return super.onAreaTouched(pSceneTouchEvent, pTouchAreaLocalX, pTouchAreaLocalY);
                              }
                          });
			//mScene.attachChild(mChickenList.get(i));
			mScene.registerTouchArea(mChickenList.get(i));
			
			//bNode tNode = mBoardList.get(0).mNode[0][i / mBoardList.get(0).mRow][i % mBoardList.get(0).mRow];
			//tNode.x -= mChickenList.get(i).getWidth() / 2;
			//tNode.y -= mChickenList.get(i).getHeight() / 2;
			//mChickenList.get(i).updateNodePos(tNode.x, tNode.y);
			//mChickenList.get(i).setStatus(tNode.v);
		}
		//mScene.setTouchAreaBindingOnActionDownEnabled(true);*/
    }
    return self;
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    /* Called when a touch begins */
    
    ChickenSprite *tChicken;
    
    for (UITouch *touch in touches)
    {
        //CGPoint location = [touch locationInNode:self];
        //[_mcSpripte updateNodePos:location];
        
        //mBoard = mBoardList.get(mBoardList.size() - 1);
        mBoard = mBoardList[[mBoardList count] - 1];
        float tx = [touch locationInNode:self].x;
        float ty = [touch locationInNode:self].y;
        ChickenNode *tNode = [mBoard getNode: tx : ty];

        if(tNode->v != 2)
        {
            for(int i = 0; i < ROWNUM * ROWNUM; i ++)
            {
                tChicken = [mChickenList objectAtIndex:i];
                if((tChicken->orgX == tNode->x) && (tChicken->orgY == tNode->y))
                {
                    _sChicken = tChicken;
                }
            }
            _sChicken->beSelected = true;
            [_sChicken setZPosition:1];
        }
        NSLog(@"began...");
    }
}

-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    ChickenSprite *tChicken;
    
    for (UITouch *touch in touches)
    {
        float tx = [touch locationInNode:self].x;
        float ty = [touch locationInNode:self].y;
        
        mBoard = mBoardList[[mBoardList count] - 1];
        if(_sChicken != nil && (_sChicken->beSelected))
        {
            ChickenNode *sNode = [mBoard getNode : _sChicken->orgX : _sChicken->orgY];
            ChickenNode *dNode = [mBoard getNode : tx : ty];
            ChickenNode *midNode = [mBoard getNode : (sNode->x + dNode->x) / 2: (sNode->y + dNode->y) / 2];
            
            int dx = (midNode->x - sNode->x) / sNode->w;
            int dy = (midNode->y - sNode->y) / sNode->w;
            
            [_sChicken setPosition : [touch locationInNode:self]];
            
            if(abs(dx) > abs(dy))
            {
                dy = 0;
                
                if(dx > 1)
                {
                    dx = 1;
                }
                else if(dx < -1)
                {
                    dx = -1;
                }
            }
            else
            {
                dx = 0;
                
                if(dy > 1)
                {
                    dy = 1;
                }
                else if(dy < -1)
                {
                    dy = -1;
                }
            }
            
            midNode = [mBoard getNode : sNode->x + dx * sNode->w : sNode->y + dy * sNode->w];
            dNode = [mBoard getNode : midNode->x * 2 - sNode->x : midNode->y * 2 - sNode->y];
            
            if((midNode->v == 1) && (dNode->v == 0))
            {
                int m;
                for(m = 0;m < ROWNUM * ROWNUM ;m ++)
                {
                    tChicken = [mChickenList objectAtIndex : m];
                    if((tChicken->orgX == midNode->x) && (tChicken->orgY == midNode->y))
                    {
                        [tChicken setHovered : true];
                        break;
                    }
                }
                
                return ;
            }
            
            for(int m = 0;m < ROWNUM * ROWNUM ; m ++)
            {
                tChicken = [mChickenList objectAtIndex : m];
                [tChicken setHovered : false];
            }
            
            return;
        }

        NSLog(@"move...");
    }
}

-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    for (UITouch *touch in touches)
    {
        ChickenSprite *tChicken;
        
        float tx = [touch locationInNode:self].x;
        float ty = [touch locationInNode:self].y;
        
        [_sChicken setZPosition:0];
        
        ChickenBoard *tBoard = mBoardList[[mBoardList count] - 1];
        mBoard = [ChickenBoard newWithValue: tBoard :0 :0 :0 ];
        //mBoard = [tBoard mutableCopy];
        if(_sChicken != nil && (_sChicken->beSelected))
        {
            _sChicken->beSelected = false;
            
            ChickenNode *sNode = [mBoard getNode : _sChicken->orgX : _sChicken->orgY];
            ChickenNode *dNode = [mBoard getNode : tx : ty];
            ChickenNode *midNode = [mBoard getNode : (sNode->x + dNode->x) / 2: (sNode->y + dNode->y) / 2];
            
            int dx = (midNode->x - sNode->x) / sNode->w;
            int dy = (midNode->y - sNode->y) / sNode->w;
            
            //if(!((dNode.x != sNode.x) && (dNode.y != sNode.y)))//
            {
                if(abs(dx) > abs(dy))
                {
                    dy = 0;
                    
                    if(dx > 1)
                    {
                        dx = 1;
                    }
                    else if(dx < -1)
                    {
                        dx = -1;
                    }
                }
                else
                {
                    dx = 0;
                    
                    if(dy > 1)
                    {
                        dy = 1;
                    }
                    else if(dy < -1)
                    {
                        dy = -1;
                    }
                }
                midNode = [mBoard getNode : sNode->x + dx * sNode->w : sNode->y + dy * sNode->w];
                dNode = [mBoard getNode : midNode->x * 2 - sNode->x : midNode->y * 2 - sNode->y];
                
                if((midNode->v == 1) && (dNode->v == 0))
                {
                    for(int m = 0;m < ROWNUM * ROWNUM ; m ++)
                    {
                        tChicken = [mChickenList objectAtIndex : m];
                        [tChicken setHovered : false];
                    }
                    
                    for(int m = 0;m < ROWNUM * ROWNUM ; m ++)
                    {
                        tChicken = [mChickenList objectAtIndex : m];
                        if((tChicken->orgX == midNode->x) && (tChicken->orgY == midNode->y))
                        {
                            [tChicken setStatus:0];
                            //[tChicken setZPosition:1];
                            [tChicken setHovered:true];
                            
                            //tChicken.registerEntityModifier(new MoveModifier(FrogTime, tChicken.getX(),FrogX - tChicken.getWidth() / 2, tChicken.getY(), FrogY, ChallengTestActivity.this));
                            
                            midNode->v = 0;
                            break;
                        }
                    }
                    
                    for(int m = 0;m < ROWNUM * ROWNUM ; m ++)
                    {
                        tChicken = [mChickenList objectAtIndex : m];
                        
                        if((tChicken->orgX == dNode->x) && (tChicken->orgY == dNode->y))
                        {
                            [tChicken updateNodePos:sNode->x : sNode->y];
                            dNode->v = 1;
                            
                            break;
                        }
                    }
                    
                    [_sChicken updateNodePos : dNode->x : dNode->y];
                    sNode->v = 0;
                    
                    [mBoardList addObject: mBoard];
                    
                    //mFrogSprite.animate(pFrogDurations2, 0, 5, 0, ChallengTestActivity.this);
                    //mHandler1.post(new Thread(mScoreRunnable));
                    if(![mBoard findAvailableMoves])
                    {
                        NSLog(@"No Available Moves!");
                        //mHandler.post(new Thread(mGameOverRunnable));
                    }
                    //return;
                }
            }
            
            [_sChicken restoreNodePos];
        }
        
        NSLog(@"end...");
    }
}

-(void)update:(CFTimeInterval)currentTime
{
    /* Called before each frame is rendered */
}

@end
