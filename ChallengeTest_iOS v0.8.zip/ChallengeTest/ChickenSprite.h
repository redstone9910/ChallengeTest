//
//  ChickenSprite.h
//  ChallengeTest
//
//  Created by YinYanhui on 14-11-16.
//  Copyright (c) 2014年 YinYanhui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <SpriteKit/SKSpriteNode.h>
#import <SpriteKit/SKTextureAtlas.h>
#import <SpriteKit/SKAction.h>

static NSMutableArray *chickenActionFrames;
static NSMutableArray *chickenBlinkFrames;
static NSMutableArray *chickenStopFrames;
static NSMutableArray *chickenBlankFrames;

@interface ChickenSprite : SKSpriteNode
{
    @public
    float orgX;
    float orgY;
    bool beSelected;
    bool beHovered;
    int v_status;
}

/*@property NSMutableArray *chickenBlinkFrames;
@property NSMutableArray *chickenActionFrames;
@property NSMutableArray *chickenStopFrames;
@property NSMutableArray *chickenBlankFrames;*/

+(instancetype) newWithAlloc : (float) spriteWidth;
-(void)saveNodePos:(float)x :(float) y;
-(void)restoreNodePos;
-(void)updateNodePos:(CGPoint)v;
-(void)updateNodePos:(float)x :(float) y;
-(void)setStatus:(int) v;
-(void)setHovered:(bool) h;
-(void)animationingChicken:(int) t;//(NSMutableArray*) chickenFrames;
@end
