//
//  AppDelegate.h
//  ChallengeTest
//
//  Created by YinYanhui on 14-11-13.
//  Copyright (c) 2014年 YinYanhui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
