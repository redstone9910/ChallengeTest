//
//  ChickenBoard.m
//  ChallengeTest
//
//  Created by YinYanhui on 14-11-15.
//  Copyright (c) 2014年 YinYanhui. All rights reserved.
//

#import "ChickenBoard.h"

static int initData[ROWNUM][ROWNUM] =
{
    {2,2,2,2,2,2,2,2,2,},
    {2,2,2,1,1,1,2,2,2,},
    {2,2,2,1,1,1,2,2,2,},
    {2,1,1,1,1,1,1,1,2,},
    {2,1,1,1,0,1,1,1,2,},
    {2,1,1,1,1,1,1,1,2,},
    {2,2,2,1,1,1,2,2,2,},
    {2,2,2,1,1,1,2,2,2,},
    {2,2,2,2,2,2,2,2,2,},
};

@implementation ChickenBoard

-(id) init: (ChickenBoard*) mBoard : (float)x : (float)y : (float)frameWidth
{
    if(self = [super init])
    {
        if(mBoard)
        {
            self -> _frameX0 = mBoard -> _frameX0;
            self -> _frameY0 = mBoard -> _frameY0;
            self -> _nodeWidth = mBoard -> _nodeWidth;
            
            ChickenNode *tChicken;
            
            self->_mNode = [NSMutableArray array];
            for (int i = 0; i < ROWNUM; i ++)
            {
                NSMutableArray *t_Node = [NSMutableArray array];
                for (int j = 0; j < ROWNUM; j ++)
                {
                    tChicken = mBoard->_mNode[i][j];
                    [t_Node addObject:[ChickenNode newWithValue: tChicken->x : tChicken->y : tChicken->w : tChicken->v ] ];
                }
                
                [self->_mNode addObject:t_Node];
            }
        }
        else
        {
            _frameX0 = x;
            _frameY0 = y;
            _nodeWidth = frameWidth / ROWNUM;
            
            self->_mNode = [NSMutableArray array];
            for (int i = 0; i < ROWNUM; i ++)
            {
                NSMutableArray *t_Node = [NSMutableArray array];
                for (int j = 0; j < ROWNUM; j ++)
                {
                    [t_Node addObject:[ChickenNode newWithValue: _frameX0 + _nodeWidth * (i + 0.5) : _frameY0 + _nodeWidth * (j + 0.5) : _nodeWidth : initData[i][j] ] ];
                }
                
                [self->_mNode addObject:t_Node];
            }
        }
    }
    return self;
}

+(ChickenBoard*) newWithValue: (ChickenBoard*) mBoard : (float)x : (float)y : (float)frameWidth
{
    return [[self alloc] init: mBoard : (float)x : (float)y : frameWidth];
}

-(void) printContent
{
    for (int i = 0; i < ROWNUM; i ++)
     {
         for (int j = 0; j < ROWNUM; j ++)
         {
             ChickenNode *tNode = [[self.mNode objectAtIndex:i] objectAtIndex:j];
             NSLog(@"x=%d,y=%d,v=%d;  ",tNode->x,tNode->y,tNode->v);
         }
         NSLog(@"\n");
     }
}

-(ChickenNode *) getNode: (int) x : (int) y
{
    //int tx = (int)round ((x - _frameX0) / _nodeWidth);
    int tx = (int)((x - _frameX0) / _nodeWidth);
    //NSLog(@"tx=%d",tx);
    tx = tx <= (ROWNUM - 1) ? tx : (ROWNUM - 1);
    tx = tx < 0 ? 0 : tx;
    
    //int ty = (int)round ((y - _frameY0) / _nodeWidth);
    int ty = (int)((y - _frameY0) / _nodeWidth);
    //NSLog(@"ty=%d",ty);
    ty = ty <= (ROWNUM - 1) ? ty : (ROWNUM - 1);
    ty = ty < 0 ? 0 : ty;
    
    return _mNode[tx][ty];
}

-(bool) findAvailableMoves
{
    for(int i = 0;i < ROWNUM;i ++)
    {
        ChickenNode *tNode;
        NSMutableString *s = [NSMutableString stringWithString:@""];
        for(int j = 0;j < ROWNUM;j ++)
        {
            tNode = _mNode[i][j];
            [s appendFormat:@"%d" ,tNode->v];
        }
        if(([s rangeOfString: @"110"].location != NSNotFound) || ([s rangeOfString: @"011"].location != NSNotFound)) return true;
    }
    
    for(int i = 0;i < ROWNUM;i ++)
    {
        ChickenNode *tNode;
        NSMutableString *s = [NSMutableString stringWithString:@""];
        for(int j = 0;j < ROWNUM;j ++)
        {
            tNode = _mNode[j][i];
            [s appendFormat:@"%d" ,tNode->v];
        }
        if(([s rangeOfString: @"110"].location != NSNotFound) || ([s rangeOfString: @"011"].location != NSNotFound)) return true;
    }
    
    return false;
}
-(id)copyWithZone:(NSZone *)zone
{
    ChickenBoard* tBoard = [[[self class] allocWithZone:zone] init:nil :0 :0 :0];
    
    tBoard -> _frameX0 = self -> _frameX0;
    tBoard -> _frameY0 = self -> _frameY0;
    tBoard -> _nodeWidth = self -> _nodeWidth;
    
    ChickenNode *tChicken;
    
    self->_mNode = [NSMutableArray array];
    for (int i = 0; i < ROWNUM; i ++)
    {
        NSMutableArray *t_Node = [NSMutableArray array];
        for (int j = 0; j < ROWNUM; j ++)
        {
            tChicken = self->_mNode[i][j];
            [t_Node addObject:[ChickenNode newWithValue: tChicken->x : tChicken->y : tChicken->w : tChicken->v ] ];
        }
        
        [tBoard->_mNode addObject:t_Node];
    }
    
    return tBoard;
}
@end
