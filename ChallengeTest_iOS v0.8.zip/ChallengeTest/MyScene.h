//
//  MyScene.h
//  ChallengeTest
//

//  Copyright (c) 2014年 YinYanhui. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>
#import "ChickenBoard.h"
#import "ChickenNode.h"
#import "ChickenSprite.h"

@interface MyScene : SKScene

@property (nonatomic, retain) ChickenSprite *sChicken;

@end
