//
//  ChickenSprite.m
//  ChallengeTest
//
//  Created by YinYanhui on 14-11-16.
//  Copyright (c) 2014年 YinYanhui. All rights reserved.
//

#import "ChickenSprite.h"

@implementation ChickenSprite

float orgX;
float orgY;
bool beSelected = false;
bool beHovered = false;
int v_status = 0;

static float resTime = 0.1f;

+(ChickenSprite *) newWithAlloc : (float) spriteWidth
{
    SKTextureAtlas *chicken = [SKTextureAtlas atlasNamed:@"ChallengeImage"];
    int numImages = (int)chicken.textureNames.count;
    
    chickenActionFrames = [NSMutableArray array];
    for (int i=1; i <= numImages - 4; i++)
    {
        NSString *textureName = [NSString stringWithFormat:@"xiaoji%02d", i];
        SKTexture *temp = [chicken textureNamed:textureName];
        [chickenActionFrames addObject:temp];
    }
    
    chickenBlinkFrames = [NSMutableArray array];
    for (int i=numImages - 3; i <= numImages - 2; i++)
    {
        NSString *textureName = [NSString stringWithFormat:@"xiaoji%02d", i];
        SKTexture *temp = [chicken textureNamed:textureName];
        [chickenBlinkFrames addObject:temp];
    }
    
    chickenStopFrames = [NSMutableArray array];
    for (int i=numImages - 1; i <= numImages - 1; i++)
    {
        NSString *textureName = [NSString stringWithFormat:@"xiaoji%02d", i];
        SKTexture *temp = [chicken textureNamed:textureName];
        [chickenStopFrames addObject:temp];
    }
    
    chickenBlankFrames = [NSMutableArray array];
    for (int i=numImages; i <= numImages; i++)
    {
        NSString *textureName = [NSString stringWithFormat:@"xiaoji%02d", i];
        SKTexture *temp = [chicken textureNamed:textureName];
        [chickenBlankFrames addObject:temp];
    }
    
    SKTexture *temp = chickenStopFrames[0];
    return [ChickenSprite spriteNodeWithTexture: temp size: CGSizeMake(spriteWidth, spriteWidth)];
    //return [ChickenSprite spriteNodeWithImageNamed:@"ChallengeImage.atlas/xiaoji01.png"];
}

-(void) saveNodePos:(float)x : (float) y
{
    orgX = x;
    orgY = y;
}

-(void)restoreNodePos
{
    [self setPosition:CGPointMake(orgX, orgY)];
}

-(void)updateNodePos:(CGPoint)v
{
    [self updateNodePos:v.x :v.y];
}

-(void)updateNodePos:(float)x :(float) y
{
    [self saveNodePos: x :y];
    SKAction *moveAction = [SKAction moveTo:CGPointMake(x, y) duration:resTime];
    [self runAction:moveAction withKey:@"movingChicken"];
}

-(void)setStatus:(int) v
{
    /*NSMutableArray *_chickenActionFrames;
    NSMutableArray *_chickenBlinkFrames;
    NSMutableArray *_chickenStopFrames;
    NSMutableArray *_chickenBlankFrames;*/
    v_status = v;
    if(v_status == 0)
    {
        //this.stopAnimation(this.getTiledTextureRegion().getTileCount() - 1);
        [self animationingChicken:4];
    }
    else if(v_status == 2)
    {
        //this.stopAnimation(this.getTiledTextureRegion().getTileCount() - 2);
        [self animationingChicken:3];
    }
    else if(v_status == 1)
    {
        if(beHovered)
        {
            //final long[] pFrameDurations = new long[this.getTiledTextureRegion().getTileCount() - 4];
            //Arrays.fill(pFrameDurations, (long)(100));
            //this.animate(pFrameDurations, 0, this.getTiledTextureRegion().getTileCount() - 5, true);
            [self animationingChicken:1];
        }
        else
        {
            //final long pDurations[] = {(long) (1000 * Math.random() * 2 + 1000),100};
            //this.animate(pDurations, this.getTiledTextureRegion().getTileCount() - 4, this.getTiledTextureRegion().getTileCount() - 3, true);
            [self animationingChicken:2];
        }
    }
}

-(void)setHovered:(bool) h
{
    if(beHovered != h)
    {
        beHovered = h;
        [self setStatus:v_status];
    }
}

-(void)animationingChicken:(int) t//(NSMutableArray*) chickenFrames
{
    //This is our general runAction method to make our bear walk.
    //By using a withKey if this gets called while already running it will remove the first action before
    //starting this again.
    
    NSMutableArray* chickenFrames;
    switch (t)
    {
        case 1:
        chickenFrames = chickenActionFrames;
        break;
        
        case 2:
        chickenFrames = chickenBlinkFrames;
        break;
        
        case 3:
        chickenFrames = chickenStopFrames;
        break;
        
        case 4:
        chickenFrames = chickenBlankFrames;
        break;
        
        default:
        break;
    }
    
    NSString *ts;
    ts = [[NSString alloc] initWithFormat:@"Status%d" , t];
    [self runAction:[SKAction repeatActionForever:[SKAction animateWithTextures:chickenFrames
                                                                    timePerFrame:0.1f
                                                                          resize:NO
                                                                         restore:YES]] withKey:ts];
    return;
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    for (UITouch *touch in touches)
    {
        CGPoint location = [touch locationInNode:self];
        NSLog(@"x=%f,y=%f;  ", location.x, location.y);
    }
}

@end
